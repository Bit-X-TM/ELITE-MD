while true
do
echo "Starting Izuku-Md..."
node lib/client.js
done
