# ELITe-MD
<div align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=MightySoulyFont&size=50&pause=1000&color=87CEEB&center=true&width=910&height=100&lines=I'M+ELITE-MD;Multi+Device+Whatsapp+Bot;Coded+By+BIT+X" alt="Typing SVG" /></a>
  
<p align="center">  
  <a href="https://youtube.com/channel/UCLUS9v7q4JagAqIJ3eeMM8w">
    <img alt=ELITE-MD height="300" src="https://telegra.ph/file/bcc7761d0c1b46c3730ba.png">
   
</a> 
    
</p>
<p align="center">
<a 

####  
Elite-MD Multi Device Whatsapp Bot.
## <sub>[External Plugins](https://github.com/AbhishekSuresh2/External-Plugins)</sub>

***
#### SESOJ id (not completed)
#### SETUP id

<a href="https://session-generate-lovat.vercel.app/"><img title="Phoenix-MD Session ID" src="https://img.shields.io/badge/GET SESSION ID-h?color=black&style=for-the-badge&logo=msi"> </a>

#### SETUP

Fork The Repo
    <br>
<a href="https://github.com/Bit-X-TM/ELITE-MD/fork"><img title="Elite-MD" src="https://img.shields.io/badge/FORK Phoenix MD-h?color=black&style=for-the-badge&logo=stackshare"></a>

#### Session ID

##### Use A United States VPN To Solve Qr/Pairing Not Connecting Problem
<a href="https://session-generate-lovat.vercel.app/"><img title="Phoenix-MD Session ID" src="https://img.shields.io/badge/GET SESSION ID-h?color=black&style=for-the-badge&logo=msi"></a>

## Elite-MD Deploy Method


### Deploy Codespace

<a href="https://github.com/codespaces/new"><img title="Elite-md Deploy CodeSpace" src="https://img.shields.io/badge/DEPLOY CODESPACE-h?color=black&style=for-the-badge&logo=visualstudiocode"></a>

### Codespace Tutorial

<a href="https://youtu.be/ZSwJtaN0BUk?si=FOsYpMs4WbvBFCpY"><img title="Phoenix-M#### SETUP
D Deploy CodeSpace" src="https://img.shields.io/badge/Codespace Tutorial-h?color=black&style=for-the-badge&logo=visualstudiocode"></a>

### Deploy Heroku 

<a href="https://phoenix-md-deploy-60f819d2cba8.herokuapp.com/heroku"><img title="Phoenix-MD Deploy Heroku" src="https://img.shields.io/badge/DEPLOY HEROKU-h?color=black&style=for-the-badge&logo=heroku"></a>

### Heroku Tutorial

<a href="https://youtu.be/sDojtm-bwN4?si=gbvAqTOSfuVRU2-k"><img title="Heroku Tutorial" src="https://img.shields.io/badge/Heroku Tutorial-h?color=black&style=for-the-badge&logo=heroku"></a>
### Deploy Railway

<a href="https://railway.app/new"><img title="Phoenix-MD Deploy Railway" src="https://img.shields.io/badge/DEPLOY RAILWAY-h?color=black&style=for-the-badge&logo=Railway"></a> 
 
 ## Support

SUPPORT GROUP: <a href="https://chat.whatsapp.com/BOLb0ICN3sAJ5dloRBw5VD"><img alt="WhatsApp" src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>

**Star ⭐ The Repo For Amazing Commands**
